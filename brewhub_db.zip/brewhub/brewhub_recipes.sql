-- MySQL dump 10.13  Distrib 8.0.27, for Win64 (x86_64)
--
-- Host: localhost    Database: brewhub
-- ------------------------------------------------------
-- Server version	8.0.27

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `recipes`
--

DROP TABLE IF EXISTS `recipes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `recipes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `owner_id` int DEFAULT NULL,
  `name` varchar(250) DEFAULT NULL,
  `style` varchar(250) DEFAULT NULL,
  `type` varchar(250) DEFAULT NULL,
  `visibility` varchar(250) DEFAULT NULL,
  `date` varchar(250) DEFAULT NULL,
  `batch_size` double DEFAULT NULL,
  `boiling_time` int DEFAULT NULL,
  `evaporation` double DEFAULT NULL,
  `boiling_losses` double DEFAULT NULL,
  `fermentation_losses` double DEFAULT NULL,
  `boil_size` double DEFAULT NULL,
  `wort_size` double DEFAULT NULL,
  `fermentables` text,
  `fermentables_amounts` text,
  `hops` text,
  `hops_usages` text,
  `hops_timings` text,
  `hops_amounts` text,
  `others` text,
  `others_amounts` text,
  `others_infos` text,
  `yeast` varchar(250) DEFAULT NULL,
  `primary_fermentation` int DEFAULT NULL,
  `secondary_fermentation` int DEFAULT NULL,
  `efficiency` double DEFAULT NULL,
  `temperature_stops` text,
  `stops_timings` text,
  `og` varchar(250) DEFAULT NULL,
  `fg` varchar(250) DEFAULT NULL,
  `ibu` double DEFAULT NULL,
  `srm` double DEFAULT NULL,
  `abv` double DEFAULT NULL,
  `notes` text,
  `price` double DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recipes`
--

LOCK TABLES `recipes` WRITE;
/*!40000 ALTER TABLE `recipes` DISABLE KEYS */;
INSERT INTO `recipes` VALUES (4,2,'Bohemian Pilsner','Czech Premium Pale Lager','All grain','Public','2022-07-07',12,60,10,20,15,18,14,'Pilsner malt','4','Saaz,Saaz','Boil,Boil','60,10','200,50','Hibiscus','10','','Hornindal',14,0,70,'67','60','1.062','1.013',10.5,4.4,6.4,'',105),(5,2,'Mango IPA','American IPA','All grain','Private','2022-07-07',10,60,10,20,15,15,12,'Marris Otter malt,Crystal malt,Wheat malt','2,1,1','Mosiac,Citra,Amarillo','Boil,Boil,Boil','60,30,20','200,50,100','Mango','500','','Hothead',20,0,70,'67','60','1.076','1.021',42.9,14.5,7.2,'',262.5),(6,2,'Coffee Stout','Irish Stout','All grain','Public','2022-07-07',15,60,10,20,15,23,17,'Chocolate malt,Marris Otter malt,Crystal malt','1,2,1','Admiral,Fuggles','Boil,Boil','60,30','120,100','Coffee','200','','Espe',14,7,70,'64,72','30,35','1.049','1.015',22.4,63,4.5,'',141.8),(7,3,'Wheat Beer','American Wheat Beer','All grain','Public','2022-07-07',14,60,10,20,15,21,16,'Wheat Malt Bestmalz,Marris Otter Fawcett','3,1','Admiral','Boil','60','150','Whirlflock','1','','Javoru',14,0,70,'66','50','1.056','1.012',18,4.3,5.8,'',95.6),(8,2,'Bohemian Pilsner B','Czech Pale Lager','All grain','Public','2022-07-07',12,60,10,20,15,18,14,'Pilsner malt','4','Magnum,Saaz','Boil,Boil','60,10','150,100','Hibiscus','20','','Gausemel',14,0,70,'68','60','1.062','1.017',27,4.4,5.9,'To jest nowy przepis',101);
/*!40000 ALTER TABLE `recipes` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-07-07 19:07:20
